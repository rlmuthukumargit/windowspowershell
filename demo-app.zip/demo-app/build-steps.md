# Manual Build and Packaging Steps

Follow these steps to build your "Hello World" application and create a deployment bundle for AWS Elastic Beanstalk (AL2023).

### 1. Build the JAR File
First, compile the source code and package the dependencies using Maven:
```bash
mvn clean package
```
This will create a "Fat JAR" in the `target/` directory: `target/demo-0.0.1-SNAPSHOT.jar`.

### 2. Prepare the Application File
Rename/copy the JAR to `application.jar` at the root of the `demo-app` folder. This is the standard name Beanstalk looks for:
```powershell
# Windows (PowerShell)
copy target\demo-0.0.1-SNAPSHOT.jar application.jar

# Linux / macOS (Bash)
cp target/demo-0.0.1-SNAPSHOT.jar application.jar
```

### 3. Create the Deployment ZIP Bundle
Combine the JAR, the `Procfile`, and the `.platform` directory into a single ZIP. **It is critical that these files are at the root of the ZIP.**

**Using tar (Recommended for Linux compatibility):**
```powershell
tar -a -c -f deploy-bundle.zip application.jar Procfile .platform
```

**Using PowerShell (Alternative):**
```powershell
Compress-Archive -Path "application.jar", "Procfile", ".platform" -DestinationPath "deploy-bundle.zip"
```

### 4. Deploy to AWS
- **Manual Upload**: Upload the resulting `deploy-bundle.zip` through the Elastic Beanstalk console.
- **S3 Upload**: Upload `deploy-bundle.zip` to your S3 bucket (e.g., `s3://elasticbeanstalk-us-east-2-infra/apps/`) and run `terraform apply`.
